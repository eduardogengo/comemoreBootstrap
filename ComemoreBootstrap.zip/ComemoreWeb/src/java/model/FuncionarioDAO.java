package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

import view.Conexao;

public class FuncionarioDAO {

	private Conexao conexao;
	private PreparedStatement prepararSQL;
	private ResultSet resultado;

	public FuncionarioDAO() throws SQLException {

		this.conexao = new Conexao();
	}

	public void inserir(Funcionario funcionario) throws SQLException {

		String sql = "insert into funcionario "
				+ "(nome, email, cpf, datacontratacao, idlogradouro, "
				+ "login, senha, idcargo, resddd, restel, celddd, celtel, rg, rgemissor, pis,"
				+ "complemento, tipoadm) "
				+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		prepararSQL = this.conexao.getConexao().prepareStatement(sql);

		//O ID est� no BD como Autoincrement -- por isso o usu�ro n�o tem que inserir o ID aqui
		prepararSQL.setString(1, funcionario.getNome());
		prepararSQL.setString(2, funcionario.getEmail());
		prepararSQL.setLong(3, funcionario.getCpf());
		prepararSQL.setDate(4, java.sql.Date.valueOf(funcionario.getDataContratacao()));
		prepararSQL.setInt(5,funcionario.getLogradouro().getId());
		prepararSQL.setString(6,funcionario.getLogin());
		prepararSQL.setString(7,funcionario.getSenha());
		prepararSQL.setInt(8,funcionario.getCargo().getId());
		prepararSQL.setInt(9,funcionario.getResddd());
		prepararSQL.setInt(10,funcionario.getRestel());
		prepararSQL.setInt(11,funcionario.getCelddd());
		prepararSQL.setInt(12,funcionario.getCeltel());
		prepararSQL.setInt(13,funcionario.getRg());
		prepararSQL.setString(14,funcionario.getRgEmissor());
		prepararSQL.setLong(15, funcionario.getPis());
		prepararSQL.setString(16, funcionario.getComplemento());
		prepararSQL.setInt(17, funcionario.getTipoAdm());
		
		
		
		prepararSQL.execute();
		prepararSQL.close();

	}
	
	
public DefaultTableModel listar() throws SQLException{
	
		
		
		String sql = "select id, nome, resddd, restel, celddd, celtel, rg, rgemissor, cpf, "
				+ "pis, datacontratacao, email, complemento, idlogradouro, login, "
				+ "senha, tipoadm, idcargo from funcionario";
		DefaultTableModel tabela = new DefaultTableModel();
	
		//n�o tem rela��o com o banco ainda
		tabela.addColumn("Id");
		tabela.addColumn("Nome");	
		tabela.addColumn("DDD");
		tabela.addColumn("Telefone");
		tabela.addColumn("DDD");
		tabela.addColumn("Celular");
		tabela.addColumn("RG");
		tabela.addColumn("Emissor");
		tabela.addColumn("CPF");
		tabela.addColumn("PIS");
		tabela.addColumn("Contratacao");
		tabela.addColumn("E-mail");
		tabela.addColumn("Complemento");
		tabela.addColumn("idlogradouro");
		tabela.addColumn("login");
		tabela.addColumn("Senha");
		tabela.addColumn("tipoadm");
		tabela.addColumn("idcargo");
				
			
		String titulo[]= {"id", "Nome", "DDD", "Telefone", "DDD", "Celular", "RG", "Emissor", "CPF",
				"PIS", "Contratacao", "E-mail", "Complemento", "idlogradouro", "login", "senha",
				"tipoadm", "idcargo"};
		
		tabela.addRow(titulo);
		
		prepararSQL = this.conexao.getConexao().prepareStatement(sql);
		
		resultado = prepararSQL.executeQuery();
		
		while(resultado.next()){
			
			String[] linha = {
								resultado.getString("id"),
								resultado.getString("nome"),
								resultado.getString("resddd"),
								resultado.getString("restel"),
								resultado.getString("celddd"),
								resultado.getString("celtel"),
								resultado.getString("rg"),
								resultado.getString("rgemissor"),
								resultado.getString("cpf"),
								resultado.getString("pis"),
								resultado.getString("datacontratacao"),
								resultado.getString("email"),
								resultado.getString("complemento"),
								resultado.getString("idlogradouro"),
								resultado.getString("login"),
								resultado.getString("senha"),
								resultado.getString("tipoadm"),
								resultado.getString("idcargo")
								
								
								
								};
			tabela.addRow(linha);
						
		}
	
		
		prepararSQL.close();
				
		
		return tabela;
		
		
		
	}


public void excluir(Funcionario funcionario) throws SQLException{
	
	
	String sql = "delete from funcionario where id = ?";
	
	prepararSQL = this.conexao.getConexao().prepareStatement(sql);
	
	
	prepararSQL.setInt(1,funcionario.getId());
	
	
	
	prepararSQL.execute();
	prepararSQL.close();
	
}

	
	

	
	
	

	
//Por enquanto n�o vou mexer aqui, pois estou na d�vida de como recuperar este ID	
	
	/*
	
	public void alterar(Cargo cargo) throws SQLException {

		String sql = "update comemore set nome=?,salario=?,altura=? where id=?";

		prepararSQL = this.conexao.getConexao().prepareStatement(sql);

		prepararSQL.setString(1, imc.getEmail());
		prepararSQL.setDouble(2, imc.getPeso());
		prepararSQL.setDouble(3, imc.getAltura());
		prepararSQL.setInt(4, imc.getId());
		prepararSQL.execute();

	}

*/

}